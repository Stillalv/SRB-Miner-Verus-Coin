#!/bin/bash

# Ambil argumen dari input
while getopts w:n: flag
do
    case "${flag}" in
        w) wallet=${OPTARG};;  # Untuk opsi wallet (-w)
        n) workername=${OPTARG};;  # Untuk opsi workername (-n)
    esac
done

# Cek apakah wallet dan workername sudah diberikan
if [ -z "$wallet" ] || [ -z "$workername" ]; then
    echo "Penggunaan: bash miner.sh -w <wallet> -n <workername>"
    exit 1
fi

# Jalankan perintah dengan parameter yang diberikan
./SRBMiner-MULTI --disable-gpu --algorithm verushash --pool ap.luckpool.net:3956 --wallet $wallet.$workername -p hybrid
